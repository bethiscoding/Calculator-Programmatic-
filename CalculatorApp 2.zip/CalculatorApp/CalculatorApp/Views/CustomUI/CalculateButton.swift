//
//  CalculateButton.swift
//  CalculatorApp
//
//  Created by Bethany Morris on 5/18/20.
//  Copyright © 2020 Bethany M. All rights reserved.
//

import UIKit

class CalculateButton: UIButton {
    
    override func awakeFromNib() {
        super.awakeFromNib()
        setUpViews()
    }
    
    func setUpViews() {
        updateFontTo(font: FontNames.hiraginoSansBold)
        self.backgroundColor = .mainGreen
        self.setTitleColor(.white, for: .normal)
        self.addCornerRadius()
    }
    
    func updateFontTo(font: String) {
        guard let size = self.titleLabel?.font.pointSize else { return }
        self.titleLabel?.font = UIFont(name: font, size: size)
        self.titleLabel?.font = UIFont.boldSystemFont(ofSize: 21)
    }
    
} //End
