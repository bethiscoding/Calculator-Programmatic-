//
//  CalculatorViewController.swift
//  CalculatorApp
//
//  Created by Bethany Morris on 5/18/20.
//  Copyright © 2020 Bethany M. All rights reserved.
//

import UIKit

class CalculatorViewController: UIViewController {
    
    // MARK: - Properties
    
    var safeArea: UILayoutGuide {
        return self.view.safeAreaLayoutGuide
    }
    
    var buttons: [UIButton] {
        return [resetButton, calculateButton]
    }
    
    var billAmount: Float = 0
    var tipPercentage: Float = 0.15
    
    var billAsString: String {
        String(format: "%.2f", billAmount)
    }
    var tipAmountAsString: String {
        String(format: "%.2f", (billAmount * tipPercentage))
    }
    var totalAsString: String {
        String(format: "%.2f", (billAmount + (billAmount * tipPercentage)))
    }
    
    // MARK: - Lifecycle
    
    override func loadView() {
        super.loadView()
        addAllSubviews()
        setUpBillStackView()
        setUpTipSegmentedControl()
        setUpTipStackView()
        setUpAmountsStackView()
        setUpBillAmountStackView()
        setUpTipAmountStackView()
        setUpTotalAmountStackView()
        setUPButtonStackView()
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.view.backgroundColor = .white
        billTextField.delegate = self
        self.view.addGestureRecognizer(UITapGestureRecognizer(target: self, action: #selector(mainViewTapped)))
        activateButtons()
    }
    
    // MARK: - Methods
    
    func addAllSubviews() {
        self.view.addSubviews(billStackView, billLabel, billTextField, tipSegmentedControl, tipStackView, tipLabel, tipAmountLabel, amountsStackView, billAmountStackView, smallBillLabel, smallBillAmountLabel, tipAmountStackView, smallTipLabel, smallTipAmountLabel, totalStackView, totalLabel, totalAmountLabel, buttonStackView, resetButton, calculateButton)
    }
    
    func setUpBillStackView() {
        billStackView.addArrangedSubview(billLabel)
        billStackView.addArrangedSubview(billTextField)
        
        billStackView.anchor(top: safeArea.topAnchor, bottom: nil, leading: safeArea.leadingAnchor, trailing: safeArea.trailingAnchor, paddingTop: 50, paddingBottom: 0, paddingLeading: 40, paddingTrailing: -40)
    }
    
    func setUpTipSegmentedControl() {
        tipSegmentedControl.anchor(top: billStackView.bottomAnchor, bottom: nil, leading: safeArea.leadingAnchor, trailing: safeArea.trailingAnchor, paddingTop: 50, paddingBottom: 0, paddingLeading: 40, paddingTrailing: -40)
    }
    
    func setUpTipStackView() {
        tipStackView.addArrangedSubview(tipLabel)
        tipStackView.addArrangedSubview(tipAmountLabel)
        
        tipStackView.anchor(top: tipSegmentedControl.bottomAnchor, bottom: nil, leading: safeArea.leadingAnchor, trailing: safeArea.trailingAnchor, paddingTop: 50, paddingBottom: 0, paddingLeading: 40, paddingTrailing: -40)
    }
    
    func setUpAmountsStackView() {
        amountsStackView.addArrangedSubview(billAmountStackView)
        amountsStackView.addArrangedSubview(tipAmountStackView)
        amountsStackView.addArrangedSubview(totalStackView)
        
        amountsStackView.anchor(top: tipStackView.bottomAnchor, bottom: nil, leading: safeArea.leadingAnchor, trailing: safeArea.trailingAnchor, paddingTop: 50, paddingBottom: 0, paddingLeading: 40, paddingTrailing: -40)
    }
    
    func setUpBillAmountStackView() {
        billAmountStackView.addArrangedSubview(smallBillLabel)
        billAmountStackView.addArrangedSubview(smallBillAmountLabel)

        billAmountStackView.anchor(top: amountsStackView.topAnchor, bottom: nil, leading: amountsStackView.leadingAnchor, trailing: amountsStackView.trailingAnchor, paddingTop: 0, paddingBottom: 0, paddingLeading: 0, paddingTrailing: 0)
    }

    func setUpTipAmountStackView() {
        tipAmountStackView.addArrangedSubview(smallTipLabel)
        tipAmountStackView.addArrangedSubview(smallTipAmountLabel)

        tipAmountStackView.anchor(top: nil, bottom: nil, leading: amountsStackView.leadingAnchor, trailing: amountsStackView.trailingAnchor, paddingTop: 0, paddingBottom: 0, paddingLeading: 0, paddingTrailing: 0)
    }

    func setUpTotalAmountStackView() {
        totalStackView.addArrangedSubview(totalLabel)
        totalStackView.addArrangedSubview(totalAmountLabel)

        totalStackView.anchor(top: nil, bottom: amountsStackView.bottomAnchor, leading: amountsStackView.leadingAnchor, trailing: amountsStackView.trailingAnchor, paddingTop: 0, paddingBottom: 0, paddingLeading: 0, paddingTrailing: 0)
    }
    
    func setUPButtonStackView() {
        buttonStackView.addArrangedSubview(resetButton)
        buttonStackView.addArrangedSubview(calculateButton)
        
        buttonStackView.anchor(top: amountsStackView.bottomAnchor, bottom: safeArea.bottomAnchor, leading: safeArea.leadingAnchor, trailing: safeArea.trailingAnchor, paddingTop: 50, paddingBottom: -50, paddingLeading: 40, paddingTrailing: -40)
    }
    
    // MARK: - Actions
    
    func tipSegmentedControlToggled(sender: UISegmentedControl) {
        if sender.selectedSegmentIndex == 0 {
            tipPercentage = 0.15
        } else if sender.selectedSegmentIndex == 1 {
            tipPercentage = 0.18
        } else {
            tipPercentage = 0.20
        }
    }
    
    @objc func selectButton(sender: UIButton) {
        switch sender {
        case resetButton:
            billTextField.text = ""
            tipAmountLabel.text = "$0.00"
            smallBillAmountLabel.text = "$0.00"
            smallTipAmountLabel.text = "$0.00"
            totalAmountLabel.text = "$0.00"
            tipSegmentedControl.selectedSegmentIndex = 0
        case calculateButton:
            tipAmountLabel.text = "$\(tipAmountAsString)"
            smallBillAmountLabel.text = "$\(billAsString)"
            smallTipAmountLabel.text = "$\(tipAmountAsString)"
            totalAmountLabel.text = "$\(totalAsString)"
        default:
            break
        }
    }
    
    func activateButtons() {
        buttons.forEach { $0.addTarget(self, action: #selector(selectButton(sender:)), for: .touchUpInside) }
    }
    
    @objc func mainViewTapped() {
        billTextField.resignFirstResponder()
    }
    
    // MARK: - Bill Stack View
    
    let billStackView: UIStackView = {
        let stackView = UIStackView()
        stackView.axis = .horizontal
        stackView.alignment = .fill
        stackView.distribution = .fillProportionally
        stackView.translatesAutoresizingMaskIntoConstraints = false
        return stackView
    }()
    
    let billLabel: UILabel = {
        let label = UILabel()
        label.text = "Bill:"
        label.textAlignment = .center
        return label
    }()
    
    let billTextField: UITextField = {
        let textField = UITextField()
        textField.placeholder = "0.00"
        return textField
    }()
    
    // MARK: - Segmented Control
    
    let tipSegmentedControl: UISegmentedControl = {
        let segmentedControl = UISegmentedControl()
        segmentedControl.insertSegment(withTitle: "15%", at: 0, animated: true)
        segmentedControl.insertSegment(withTitle: "18%", at: 1, animated: true)
        segmentedControl.insertSegment(withTitle: "20%", at: 2, animated: true)
        return segmentedControl
    }()
    
    // MARK: - Tip Stack View
    
    let tipStackView: UIStackView = {
        let stackView = UIStackView()
        stackView.axis = .horizontal
        stackView.alignment = .fill
        stackView.distribution = .fillProportionally
        stackView.translatesAutoresizingMaskIntoConstraints = false
        return stackView
    }()
    
    let tipLabel: UILabel = {
        let label = UILabel()
        label.text = "Tip:"
        label.textAlignment = .center
        return label
    }()
    
    let tipAmountLabel: UILabel = {
        let label = UILabel()
        label.text = "$0.00"
        return label
    }()
    
    // MARK: - Amounts Stack View
    
    let amountsStackView: UIStackView = {
        let stackView = UIStackView()
        stackView.axis = .vertical
        stackView.alignment = .fill
        stackView.distribution = .fillEqually
        stackView.translatesAutoresizingMaskIntoConstraints = false
        return stackView
    }()
    
    let billAmountStackView: UIStackView = {
        let stackView = UIStackView()
        stackView.axis = .horizontal
        stackView.alignment = .fill
        stackView.distribution = .fillProportionally
        stackView.translatesAutoresizingMaskIntoConstraints = false
        return stackView
    }()
    
    let smallBillLabel: UILabel = {
        let label = UILabel()
        label.text = "Bill Amount:"
        return label
    }()
    
    let smallBillAmountLabel: UILabel = {
        let label = UILabel()
        label.text = "$0.00"
        return label
    }()
    
    let tipAmountStackView: UIStackView = {
        let stackView = UIStackView()
        stackView.axis = .horizontal
        stackView.alignment = .fill
        stackView.distribution = .fillProportionally
        stackView.translatesAutoresizingMaskIntoConstraints = false
        return stackView
    }()
    
    let smallTipLabel: UILabel = {
        let label = UILabel()
        label.text = "Tip Amount:"
        return label
    }()
    
    let smallTipAmountLabel: UILabel = {
        let label = UILabel()
        label.text = "$0.00"
        return label
    }()
    
    let totalStackView: UIStackView = {
        let stackView = UIStackView()
        stackView.axis = .horizontal
        stackView.alignment = .fill
        stackView.distribution = .fillProportionally
        stackView.translatesAutoresizingMaskIntoConstraints = false
        return stackView
    }()
    
    let totalLabel: UILabel = {
        let label = UILabel()
        label.text = "Total Amount:"
        return label
    }()
    
    let totalAmountLabel: UILabel = {
        let label = UILabel()
        label.text = "$0.00"
        return label
    }()
    
    // MARK: - Button Stack View
    
    let buttonStackView: UIStackView = {
        let stackView = UIStackView()
        stackView.axis = .horizontal
        stackView.alignment = .fill
        stackView.distribution = .fillEqually
        stackView.translatesAutoresizingMaskIntoConstraints = false
        return stackView
    }()
    
    let resetButton: UIButton = {
        let button = UIButton()
        button.setTitle("Reset", for: .normal)
        button.backgroundColor = .accentGreen
        button.setTitleColor(.white, for: .normal)
        return button
    }()
    
    let calculateButton: UIButton = {
        let button = UIButton()
        button.setTitle("Calculate", for: .normal)
        button.backgroundColor = .mainGreen
        button.setTitleColor(.white, for: .normal)
        return button
    }()
    
} //End

// MARK: - Extensions

extension CalculatorViewController: UITextFieldDelegate {
    
    func textFieldDidBeginEditing(_ textField: UITextField) {
        textField.keyboardType = .decimalPad
    }
    
    func textFieldDidEndEditing(_ textField: UITextField) {
        billAmount = (textField.text as! NSString).floatValue
    }
    
    func textField(_ textField: UITextField, shouldChangeCharactersIn range: NSRange, replacementString string: String) -> Bool {
        let dotString = "."
        
        if let text = textField.text {
            let isDeleteKey = string.isEmpty
            
            if !isDeleteKey {
                if text.contains(dotString) {
                    if text.components(separatedBy: dotString)[1].count == 2 {
                        return false
                    }
                }
            }
        }
        return true
    }
    
} //End

extension CalculatorViewController: UIGestureRecognizerDelegate {
    
    
    
}
