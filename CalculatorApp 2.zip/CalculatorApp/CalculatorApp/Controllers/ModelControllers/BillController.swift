//
//  BillController.swift
//  CalculatorApp
//
//  Created by Bethany Morris on 5/18/20.
//  Copyright © 2020 Bethany M. All rights reserved.
//

import Foundation

class BillController {
    
    static let sharedInstance = BillController()
    
    func calculateTip(bill: Float, tipPercentage: Float) -> Float {
        
        let tip = bill * tipPercentage
        return tip
    }
    
} //End
