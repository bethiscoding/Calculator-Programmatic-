//
//  Bill.swift
//  CalculatorApp
//
//  Created by Bethany Morris on 5/18/20.
//  Copyright © 2020 Bethany M. All rights reserved.
//

import Foundation

class Bill {
    
    var billAmount: Float
    var tipAmount: Float
    var totalAmount: Float
    
    init(billAmount: Float, tipAmount: Float, totalAmount: Float) {
        self.billAmount = billAmount
        self.tipAmount = tipAmount
        self.totalAmount = totalAmount
    }
    
} //End
